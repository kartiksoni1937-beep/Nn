package com.kartik.performanceunlocker.data

data class SystemMetrics(
    val cpuUsagePercent: Float,          // 0–100, from /proc/stat
    val cpuFreqMhz: Int,                  // Current CPU freq in MHz, from sysfs
    val cpuMaxFreqMhz: Int,               // Max CPU freq in MHz
    val cpuCoreCount: Int,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val ramAvailableMb: Long,
    val batteryPercent: Int,
    val batteryTempCelsius: Float,
    val isCharging: Boolean,
    val thermalStatus: Int,               // PowerManager.THERMAL_STATUS_* value
    val thermalLabel: String,             // "Normal", "Light", "Moderate", "Severe", "Critical"
    val displayRefreshRateHz: Float,
    val storageFreeGb: Float,
    val storageTotalGb: Float,
    val gpuInfoAvailable: Boolean,
    val gpuFreqMhz: Int,                  // -1 if not accessible
    val timestamp: Long = System.currentTimeMillis()
) {
    val ramUsagePercent: Float get() =
        if (ramTotalMb > 0) (ramUsedMb.toFloat() / ramTotalMb * 100f) else 0f

    val isThermalWarning: Boolean get() =
        thermalStatus >= 3  // THERMAL_STATUS_SEVERE or worse

    val cpuFreqPercent: Float get() =
        if (cpuMaxFreqMhz > 0) (cpuFreqMhz.toFloat() / cpuMaxFreqMhz * 100f) else 0f

    companion object {
        fun empty() = SystemMetrics(
            cpuUsagePercent = 0f,
            cpuFreqMhz = 0,
            cpuMaxFreqMhz = 2200,
            cpuCoreCount = 8,
            ramUsedMb = 0,
            ramTotalMb = 8192,
            ramAvailableMb = 0,
            batteryPercent = 100,
            batteryTempCelsius = 30f,
            isCharging = false,
            thermalStatus = 0,
            thermalLabel = "Normal",
            displayRefreshRateHz = 90f,
            storageFreeGb = 100f,
            storageTotalGb = 256f,
            gpuInfoAvailable = false,
            gpuFreqMhz = -1
        )
    }
}

data class GameInfo(
    val packageName: String,
    val appName: String,
    val assignedProfile: GamingProfile = GamingProfile.BALANCED
)

enum class GamingProfile(val displayName: String, val description: String) {
    MAX_PERFORMANCE(
        "Max Performance",
        "Enables WiFi low-latency lock, CPU wake lock, DnD mode, and max refresh rate. " +
        "Best FPS but uses more battery and generates more heat."
    ),
    BALANCED(
        "Balanced",
        "WiFi lock active, DnD mode on. Normal screen brightness. " +
        "Good performance without excessive battery drain."
    ),
    BATTERY_SAVER(
        "Battery Saver",
        "Reduced brightness, no wake lock. Prioritizes battery life over peak FPS. " +
        "Suitable for long sessions on low charge."
    ),
    CUSTOM(
        "Custom",
        "Your own combination of available settings. Configure in the Optimization Center."
    )
}
