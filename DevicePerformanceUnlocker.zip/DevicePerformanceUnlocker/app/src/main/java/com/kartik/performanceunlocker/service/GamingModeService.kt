package com.kartik.performanceunlocker.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.kartik.performanceunlocker.MainActivity
import com.kartik.performanceunlocker.R
import com.kartik.performanceunlocker.data.GamingProfile
import com.kartik.performanceunlocker.util.GameOptimizer

/**
 * Foreground service that maintains gaming optimizations (WiFi lock, wake lock)
 * even when the optimizer app is in the background while the game runs.
 */
class GamingModeService : Service() {

    private lateinit var optimizer: GameOptimizer

    companion object {
        const val CHANNEL_ID = "gaming_mode_channel"
        const val ACTION_START = "START_GAMING"
        const val ACTION_STOP = "STOP_GAMING"
        const val EXTRA_PROFILE = "profile"
        const val EXTRA_PACKAGE = "package"
    }

    override fun onCreate() {
        super.onCreate()
        optimizer = GameOptimizer(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val profileName = intent.getStringExtra(EXTRA_PROFILE) ?: GamingProfile.BALANCED.name
                val gamePackage = intent.getStringExtra(EXTRA_PACKAGE)
                val profile = GamingProfile.valueOf(profileName)

                optimizer.applyProfile(profile, gamePackage)
                startForeground(1, buildNotification(profile.displayName))
            }
            ACTION_STOP -> {
                optimizer.releaseAll()
                optimizer.restoreDnd()
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        optimizer.releaseAll()
        optimizer.restoreDnd()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(profileName: String): Notification {
        val stopIntent = Intent(this, GamingModeService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Gaming Mode Active")
            .setContentText("Profile: $profileName — WiFi & CPU locks held")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPending)
            .addAction(
                Notification.Action.Builder(
                    null, "Stop", stopPending
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Gaming Mode",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while gaming mode optimizations are active"
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }
}
