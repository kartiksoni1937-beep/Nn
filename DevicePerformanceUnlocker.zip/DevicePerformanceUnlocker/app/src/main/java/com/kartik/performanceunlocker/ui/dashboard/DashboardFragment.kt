package com.kartik.performanceunlocker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.kartik.performanceunlocker.data.GamingProfile
import com.kartik.performanceunlocker.databinding.FragmentDashboardBinding

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val vm: DashboardViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        vm.metrics.observe(viewLifecycleOwner) { m ->
            binding.tvCpuValue.text = "%.0f%%".format(m.cpuUsagePercent)
            binding.tvCpuFreq.text = "${m.cpuFreqMhz} MHz"
            binding.progressCpu.progress = m.cpuUsagePercent.toInt()

            binding.tvRamValue.text = "${m.ramUsedMb} / ${m.ramTotalMb} MB"
            binding.progressRam.progress = m.ramUsagePercent.toInt()

            binding.tvBatteryValue.text = "${m.batteryPercent}%"
            binding.tvBatteryTemp.text = "%.1f°C".format(m.batteryTempCelsius)
            binding.tvChargingStatus.text = if (m.isCharging) "⚡ Charging" else "On battery"

            binding.tvThermalStatus.text = m.thermalLabel
            binding.tvThermalStatus.setTextColor(
                if (m.isThermalWarning)
                    requireContext().getColor(android.R.color.holo_red_light)
                else
                    requireContext().getColor(android.R.color.holo_green_light)
            )

            binding.tvRefreshRate.text = "%.0f Hz".format(m.displayRefreshRateHz)
            binding.tvStorage.text = "%.1f / %.1f GB free".format(m.storageFreeGb, m.storageTotalGb)
        }

        vm.activeProfile.observe(viewLifecycleOwner) { profile ->
            binding.tvActiveProfile.text = profile.displayName
            binding.tvProfileDesc.text = profile.description
        }

        // Profile quick-select chips
        binding.chipMax.setOnClickListener { vm.setProfile(GamingProfile.MAX_PERFORMANCE) }
        binding.chipBalanced.setOnClickListener { vm.setProfile(GamingProfile.BALANCED) }
        binding.chipBattery.setOnClickListener { vm.setProfile(GamingProfile.BATTERY_SAVER) }

        vm.startMonitoring()
    }

    override fun onResume() {
        super.onResume()
        vm.startMonitoring()
    }

    override fun onPause() {
        super.onPause()
        vm.stopMonitoring()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
