package com.kartik.performanceunlocker.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kartik.performanceunlocker.data.GamingProfile
import com.kartik.performanceunlocker.data.SystemMetrics
import com.kartik.performanceunlocker.util.MetricsCollector
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DashboardViewModel(app: Application) : AndroidViewModel(app) {

    private val collector = MetricsCollector(app)

    private val _metrics = MutableLiveData(SystemMetrics.empty())
    val metrics: LiveData<SystemMetrics> = _metrics

    private val _activeProfile = MutableLiveData(GamingProfile.BALANCED)
    val activeProfile: LiveData<GamingProfile> = _activeProfile

    private var pollingJob: Job? = null

    fun startMonitoring(intervalMs: Long = 2000L) {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (isActive) {
                _metrics.postValue(collector.collect())
                delay(intervalMs)
            }
        }
    }

    fun stopMonitoring() {
        pollingJob?.cancel()
    }

    fun setProfile(profile: GamingProfile) {
        _activeProfile.value = profile
    }

    override fun onCleared() {
        super.onCleared()
        stopMonitoring()
    }
}
