package com.kartik.performanceunlocker.ui.diagnostics

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.kartik.performanceunlocker.databinding.FragmentDiagnosticsBinding
import com.kartik.performanceunlocker.util.CapabilityChecker
import com.kartik.performanceunlocker.util.MetricsCollector
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DiagnosticsFragment : Fragment() {

    private var _binding: FragmentDiagnosticsBinding? = null
    private val binding get() = _binding!!
    private lateinit var checker: CapabilityChecker
    private lateinit var collector: MetricsCollector
    private var reportText = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDiagnosticsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checker = CapabilityChecker(requireContext())
        collector = MetricsCollector(requireContext())

        binding.btnRunDiagnostics.setOnClickListener {
            runDiagnostics()
        }

        binding.btnExportReport.setOnClickListener {
            exportReport()
        }

        // Device info — always available
        binding.tvDeviceInfo.text = buildDeviceInfo()
    }

    private fun runDiagnostics() {
        binding.progressDiag.visibility = View.VISIBLE
        binding.btnRunDiagnostics.isEnabled = false

        viewLifecycleOwner.lifecycleScope.launch {
            val metrics = collector.collect()
            val capabilities = checker.checkAll()

            val sb = StringBuilder()
            sb.appendLine("=== DEVICE PERFORMANCE DIAGNOSTICS ===")
            sb.appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}")
            sb.appendLine()

            sb.appendLine("--- DEVICE ---")
            sb.appendLine(buildDeviceInfo())
            sb.appendLine()

            sb.appendLine("--- LIVE METRICS ---")
            sb.appendLine("CPU Usage:    %.1f%%".format(metrics.cpuUsagePercent))
            sb.appendLine("CPU Freq:     ${if (metrics.cpuFreqMhz > 0) "${metrics.cpuFreqMhz} MHz" else "Not readable"}")
            sb.appendLine("CPU Max Freq: ${metrics.cpuMaxFreqMhz} MHz")
            sb.appendLine("CPU Cores:    ${metrics.cpuCoreCount}")
            sb.appendLine("RAM Used:     ${metrics.ramUsedMb} MB / ${metrics.ramTotalMb} MB (%.1f%%)".format(metrics.ramUsagePercent))
            sb.appendLine("RAM Free:     ${metrics.ramAvailableMb} MB")
            sb.appendLine("Battery:      ${metrics.batteryPercent}% @ %.1f°C".format(metrics.batteryTempCelsius))
            sb.appendLine("Charging:     ${metrics.isCharging}")
            sb.appendLine("Thermal:      ${metrics.thermalLabel} (code ${metrics.thermalStatus})")
            sb.appendLine("Display:      %.0f Hz".format(metrics.displayRefreshRateHz))
            sb.appendLine("Storage Free: %.1f GB / %.1f GB".format(metrics.storageFreeGb, metrics.storageTotalGb))
            sb.appendLine("GPU Freq:     ${if (metrics.gpuInfoAvailable) "${metrics.gpuFreqMhz} MHz" else "Not readable (root required)"}")
            sb.appendLine()

            sb.appendLine("--- BOTTLENECK ANALYSIS ---")
            when {
                metrics.cpuUsagePercent > 85 ->
                    sb.appendLine("⚠ CPU is the bottleneck (>85% usage). Reduce background apps.")
                metrics.ramUsagePercent > 90 ->
                    sb.appendLine("⚠ RAM near full (>90%). Close background apps.")
                metrics.batteryTempCelsius >= 45 ->
                    sb.appendLine("🔴 Device overheating (${metrics.batteryTempCelsius}°C). Stop charging while gaming.")
                metrics.batteryTempCelsius >= 38 ->
                    sb.appendLine("⚠ Device warm (${metrics.batteryTempCelsius}°C). Remove case and reduce graphics.")
                metrics.thermalStatus >= 3 ->
                    sb.appendLine("⚠ Thermal throttling active. CPU/GPU running below max speed.")
                else ->
                    sb.appendLine("✅ No obvious bottleneck detected at measurement time.")
            }
            sb.appendLine()

            sb.appendLine("--- CAPABILITY ASSESSMENT ---")
            capabilities.forEach { cap ->
                val icon = when (cap.status) {
                    CapabilityChecker.Status.SUPPORTED -> "✅"
                    CapabilityChecker.Status.PERMISSION_NEEDED -> "⚠"
                    CapabilityChecker.Status.UNAVAILABLE -> "❌"
                }
                sb.appendLine("$icon ${cap.name}")
                sb.appendLine("   ${cap.detail}")
            }

            reportText = sb.toString()
            binding.tvDiagnosticsOutput.text = reportText
            binding.progressDiag.visibility = View.GONE
            binding.btnRunDiagnostics.isEnabled = true
            binding.btnExportReport.isEnabled = true
        }
    }

    private fun buildDeviceInfo(): String {
        return buildString {
            appendLine("Device:  ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Build:   ${Build.DISPLAY}")
            appendLine("CPU ABI: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
            append("SOC:     ${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}")
        }
    }

    private fun exportReport() {
        if (reportText.isEmpty()) return
        try {
            val dir = File(requireContext().cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "dpu_report_${System.currentTimeMillis()}.txt")
            file.writeText(reportText)

            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.provider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Diagnostic Report"))
        } catch (e: Exception) {
            binding.tvDiagnosticsOutput.text =
                "${binding.tvDiagnosticsOutput.text}\n\nExport failed: ${e.message}"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
