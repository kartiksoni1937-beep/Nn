package com.kartik.performanceunlocker.ui.gaming

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kartik.performanceunlocker.R
import com.kartik.performanceunlocker.data.GameInfo

class GameAdapter(
    private val games: List<GameInfo>,
    private val onGameSelected: (GameInfo) -> Unit
) : RecyclerView.Adapter<GameAdapter.GameViewHolder>() {

    private var selectedPosition = RecyclerView.NO_ID.toInt()

    inner class GameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.ivGameIcon)
        val name: TextView = itemView.findViewById(R.id.tvGameName)
        val selectedOverlay: View = itemView.findViewById(R.id.viewSelected)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_game, parent, false)
        return GameViewHolder(v)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        val game = games[position]
        holder.name.text = game.appName

        // Load app icon
        try {
            val pm = holder.itemView.context.packageManager
            val appInfo = pm.getApplicationInfo(game.packageName, 0)
            holder.icon.setImageDrawable(pm.getApplicationIcon(appInfo))
        } catch (e: PackageManager.NameNotFoundException) {
            holder.icon.setImageResource(android.R.drawable.sym_def_app_icon)
        }

        holder.selectedOverlay.visibility =
            if (position == selectedPosition) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener {
            val prev = selectedPosition
            selectedPosition = holder.adapterPosition
            notifyItemChanged(prev)
            notifyItemChanged(selectedPosition)
            onGameSelected(game)
        }
    }

    override fun getItemCount() = games.size
}
