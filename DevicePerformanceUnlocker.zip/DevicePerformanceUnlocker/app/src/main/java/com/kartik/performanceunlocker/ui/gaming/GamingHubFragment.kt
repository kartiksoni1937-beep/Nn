package com.kartik.performanceunlocker.ui.gaming

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.kartik.performanceunlocker.data.GameInfo
import com.kartik.performanceunlocker.data.GamingProfile
import com.kartik.performanceunlocker.databinding.FragmentGamingHubBinding
import com.kartik.performanceunlocker.service.GamingModeService
import com.kartik.performanceunlocker.util.GameOptimizer

class GamingHubFragment : Fragment() {

    private var _binding: FragmentGamingHubBinding? = null
    private val binding get() = _binding!!
    private lateinit var optimizer: GameOptimizer
    private var selectedGame: GameInfo? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGamingHubBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        optimizer = GameOptimizer(requireContext())

        val games = detectInstalledGames()
        val adapter = GameAdapter(games) { game ->
            selectedGame = game
            binding.tvSelectedGame.text = "Selected: ${game.appName}"
            binding.btnLaunchGame.isEnabled = true
        }

        binding.rvGames.layoutManager = GridLayoutManager(requireContext(), 3)
        binding.rvGames.adapter = adapter

        if (games.isEmpty()) {
            binding.tvNoGames.visibility = View.VISIBLE
        }

        binding.btnLaunchGame.setOnClickListener {
            selectedGame?.let { game ->
                val profile = getSelectedProfile()
                startGamingMode(game, profile)
                launchGame(game.packageName)
            }
        }

        binding.btnStopGaming.setOnClickListener {
            stopGamingMode()
        }
    }

    /**
     * Detect installed apps that are likely games.
     * Uses PackageManager with CATEGORY_GAME flag and heuristics.
     */
    private fun detectInstalledGames(): List<GameInfo> {
        val pm = requireContext().packageManager
        val allApps = try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        } catch (e: Exception) {
            emptyList()
        }

        return allApps.filter { app ->
            val isGame = (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val isGameCategory = app.category == ApplicationInfo.CATEGORY_GAME
            val isNotSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            val hasGameKeyword = listOf("game", "play", "battle", "arena", "mobile", "pubg",
                "bgmi", "cod", "clash", "free fire", "minecraft", "roblox", "genshin")
                .any { app.packageName.lowercase().contains(it) }
            (isGame || isGameCategory || hasGameKeyword) && isNotSystem
        }.mapNotNull { app ->
            try {
                val label = pm.getApplicationLabel(app).toString()
                GameInfo(app.packageName, label)
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.appName }
    }

    private fun getSelectedProfile(): GamingProfile {
        return when (binding.rgProfile.checkedRadioButtonId) {
            binding.rbMax.id -> GamingProfile.MAX_PERFORMANCE
            binding.rbBattery.id -> GamingProfile.BATTERY_SAVER
            else -> GamingProfile.BALANCED
        }
    }

    private fun startGamingMode(game: GameInfo, profile: GamingProfile) {
        val intent = Intent(requireContext(), GamingModeService::class.java).apply {
            action = GamingModeService.ACTION_START
            putExtra(GamingModeService.EXTRA_PROFILE, profile.name)
            putExtra(GamingModeService.EXTRA_PACKAGE, game.packageName)
        }
        requireContext().startForegroundService(intent)

        binding.tvGamingStatus.text = "🎮 Gaming Mode: ${profile.displayName} active"
        binding.tvGamingStatus.visibility = View.VISIBLE
        binding.btnStopGaming.visibility = View.VISIBLE
        Toast.makeText(requireContext(), "Gaming mode started: ${profile.displayName}", Toast.LENGTH_SHORT).show()
    }

    private fun stopGamingMode() {
        val intent = Intent(requireContext(), GamingModeService::class.java).apply {
            action = GamingModeService.ACTION_STOP
        }
        requireContext().startService(intent)

        binding.tvGamingStatus.text = "Gaming mode stopped"
        binding.btnStopGaming.visibility = View.GONE
        Toast.makeText(requireContext(), "Gaming mode stopped, settings restored", Toast.LENGTH_SHORT).show()
    }

    private fun launchGame(packageName: String) {
        val pm = requireContext().packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(requireContext(), "Cannot launch — app not found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
