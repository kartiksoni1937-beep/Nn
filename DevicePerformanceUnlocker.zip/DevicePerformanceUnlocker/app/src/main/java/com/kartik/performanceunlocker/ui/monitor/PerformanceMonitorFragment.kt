package com.kartik.performanceunlocker.ui.monitor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.kartik.performanceunlocker.databinding.FragmentPerformanceMonitorBinding
import com.kartik.performanceunlocker.util.MetricsCollector
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PerformanceMonitorFragment : Fragment() {

    private var _binding: FragmentPerformanceMonitorBinding? = null
    private val binding get() = _binding!!
    private lateinit var collector: MetricsCollector
    private var job: Job? = null

    // Simple ring buffer for CPU history (last 30 samples)
    private val cpuHistory = ArrayDeque<Float>(30)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPerformanceMonitorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        collector = MetricsCollector(requireContext())

        startPolling()
    }

    private fun startPolling() {
        job = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                val m = collector.collect()

                // CPU
                binding.tvCpuUsage.text = "CPU: %.1f%%".format(m.cpuUsagePercent)
                binding.tvCpuFreqDetail.text =
                    if (m.cpuFreqMhz > 0) "${m.cpuFreqMhz} MHz / ${m.cpuMaxFreqMhz} MHz"
                    else "Freq: not readable (typical on HyperOS)"
                binding.progressCpuMonitor.progress = m.cpuUsagePercent.toInt()
                binding.tvCpuCores.text = "${m.cpuCoreCount} cores"

                // RAM
                binding.tvRamDetail.text =
                    "RAM: ${m.ramUsedMb} MB used / ${m.ramTotalMb} MB total"
                binding.tvRamAvail.text = "${m.ramAvailableMb} MB available"
                binding.progressRamMonitor.progress = m.ramUsagePercent.toInt()

                // Thermal
                binding.tvThermalDetail.text = "Thermal: ${m.thermalLabel}"
                binding.tvBatteryTempDetail.text =
                    "Battery temp: %.1f°C".format(m.batteryTempCelsius)

                val tempColor = when {
                    m.batteryTempCelsius >= 45 -> requireContext().getColor(android.R.color.holo_red_light)
                    m.batteryTempCelsius >= 38 -> requireContext().getColor(android.R.color.holo_orange_light)
                    else -> requireContext().getColor(android.R.color.holo_green_light)
                }
                binding.tvBatteryTempDetail.setTextColor(tempColor)

                // GPU
                binding.tvGpuDetail.text = if (m.gpuInfoAvailable) {
                    "GPU: ${m.gpuFreqMhz} MHz"
                } else {
                    "GPU freq: not readable without root (MediaTek sysfs locked)"
                }

                // Display
                binding.tvRefreshDetail.text =
                    "Display: %.0f Hz refresh rate".format(m.displayRefreshRateHz)

                // History ring buffer
                if (cpuHistory.size >= 30) cpuHistory.removeFirst()
                cpuHistory.addLast(m.cpuUsagePercent)
                binding.tvCpuAvg.text =
                    "Avg (30s): %.1f%%".format(cpuHistory.average())

                delay(2000L)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        job?.cancel()
        _binding = null
    }
}
