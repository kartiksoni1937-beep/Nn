package com.kartik.performanceunlocker.ui.optimize

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.kartik.performanceunlocker.databinding.FragmentOptimizationBinding
import com.kartik.performanceunlocker.util.GameOptimizer

class OptimizationFragment : Fragment() {

    private var _binding: FragmentOptimizationBinding? = null
    private val binding get() = _binding!!
    private lateinit var optimizer: GameOptimizer

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOptimizationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        optimizer = GameOptimizer(requireContext())

        // WiFi Lock
        binding.btnWifiLock.setOnClickListener {
            val result = optimizer.acquireWifiLock(lowLatency = true)
            showResult(result.action, result.applied, result.reason)
        }

        // Wake Lock
        binding.btnWakeLock.setOnClickListener {
            val result = optimizer.acquireWakeLock()
            showResult(result.action, result.applied, result.reason)
        }

        // DND
        binding.btnDnd.setOnClickListener {
            val result = optimizer.applyDndMode(enable = true)
            if (!result.applied) {
                // Open DND permission settings
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            } else {
                showResult(result.action, result.applied, result.reason)
            }
        }

        // Grant WRITE_SETTINGS
        binding.btnWriteSettings.setOnClickListener {
            if (!Settings.System.canWrite(requireContext())) {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${requireContext().packageName}")
                }
                startActivity(intent)
            } else {
                Toast.makeText(requireContext(), "Write Settings already granted", Toast.LENGTH_SHORT).show()
            }
        }

        // Grant Usage Access
        binding.btnUsageAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        // Brightness control (only if WRITE_SETTINGS granted)
        binding.seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    binding.tvBrightnessValue.text = "$progress%"
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                val raw = (sb.progress / 100f * 255).toInt()
                val result = optimizer.setBrightness(raw)
                showResult(result.action, result.applied, result.reason)
            }
        })

        // Open battery optimization settings
        binding.btnBatteryOptimization.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        // Open app info
        binding.btnAppManagement.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))
        }

        // Release all
        binding.btnReleaseAll.setOnClickListener {
            optimizer.releaseAll()
            optimizer.restoreDnd()
            Toast.makeText(requireContext(), "All optimizations released. Settings restored.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showResult(action: String, applied: Boolean, reason: String) {
        val icon = if (applied) "✅" else "⚠"
        binding.tvOptimizeLog.text =
            (binding.tvOptimizeLog.text.toString() + "\n$icon $action: $reason")
                .lines().takeLast(8).joinToString("\n")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
