package com.kartik.performanceunlocker.ui.settings

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.kartik.performanceunlocker.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = requireContext().getSharedPreferences("dpu_settings", 0)

        // Load saved settings
        binding.switchAutoStartGaming.isChecked =
            prefs.getBoolean("auto_start_gaming", false)
        binding.switchRestoreDnd.isChecked =
            prefs.getBoolean("restore_dnd", true)
        binding.seekPollInterval.progress =
            prefs.getInt("poll_interval_idx", 1) // 0=1s, 1=2s, 2=5s

        updatePollLabel()

        // Save on change
        binding.switchAutoStartGaming.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_start_gaming", checked).apply()
        }
        binding.switchRestoreDnd.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("restore_dnd", checked).apply()
        }
        binding.seekPollInterval.setOnSeekBarChangeListener(object :
            android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: android.widget.SeekBar, p: Int, u: Boolean) {
                prefs.edit().putInt("poll_interval_idx", p).apply()
                updatePollLabel()
            }
            override fun onStartTrackingTouch(s: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(s: android.widget.SeekBar) {}
        })

        // App version info
        try {
            val pi = requireContext().packageManager.getPackageInfo(requireContext().packageName, 0)
            binding.tvVersion.text = "Version ${pi.versionName}"
        } catch (_: Exception) {}

        binding.tvCapabilities.text = buildString {
            appendLine("Real optimizations in this app:")
            appendLine("✅ WiFi Low-Latency Lock (reduces ping)")
            appendLine("✅ CPU Wake Lock (prevents sleep)")
            appendLine("✅ Do Not Disturb (block interruptions)")
            appendLine("✅ Battery temperature monitoring")
            appendLine("✅ Thermal throttling detection (API 29+)")
            appendLine("✅ CPU usage monitoring (/proc/stat)")
            appendLine("✅ RAM monitoring (ActivityManager)")
            appendLine("✅ Game library detection")
            appendLine("✅ Per-game profile launch")
            appendLine()
            appendLine("NOT possible without root:")
            appendLine("❌ CPU/GPU overclocking")
            appendLine("❌ CPU governor change")
            appendLine("❌ Force-stop other apps")
            appendLine("❌ GPU frequency control")
        }
    }

    private fun updatePollLabel() {
        val intervals = listOf("Every 1 second", "Every 2 seconds", "Every 5 seconds")
        val idx = binding.seekPollInterval.progress.coerceIn(0, intervals.lastIndex)
        binding.tvPollInterval.text = intervals[idx]
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
