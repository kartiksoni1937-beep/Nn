package com.kartik.performanceunlocker.util

import android.app.GameManager
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import java.io.File

/**
 * Honest capability assessment — checks what this device actually supports.
 * Reports SUPPORTED, PERMISSION_NEEDED, or UNAVAILABLE for each feature.
 */
class CapabilityChecker(private val context: Context) {

    enum class Status { SUPPORTED, PERMISSION_NEEDED, UNAVAILABLE }

    data class Capability(
        val name: String,
        val status: Status,
        val detail: String,
        val actionLabel: String? = null  // label for a button to fix it, if applicable
    )

    fun checkAll(): List<Capability> = listOf(
        checkWifiLock(),
        checkWakeLock(),
        checkDndMode(),
        checkWriteSettings(),
        checkGameManager(),
        checkThermalApi(),
        checkUsageStats(),
        checkCpuFreqRead(),
        checkGpuFreqRead(),
        checkCpuOverclock(),
        checkGpuOverclock()
    )

    fun checkWifiLock() = Capability(
        name = "WiFi Low-Latency Lock",
        status = Status.SUPPORTED,
        detail = "✅ Supported — reduces WiFi latency during online gaming. " +
                 "No extra permission needed."
    )

    fun checkWakeLock() = Capability(
        name = "CPU Wake Lock",
        status = Status.SUPPORTED,
        detail = "✅ Supported — prevents CPU sleep during gaming. " +
                 "WAKE_LOCK permission declared."
    )

    fun checkDndMode(): Capability {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return if (nm.isNotificationPolicyAccessGranted) {
            Capability(
                name = "Do Not Disturb (DND)",
                status = Status.SUPPORTED,
                detail = "✅ Permission granted — will block notifications during gaming."
            )
        } else {
            Capability(
                name = "Do Not Disturb (DND)",
                status = Status.PERMISSION_NEEDED,
                detail = "⚠ Requires user to grant DND permission in Settings.",
                actionLabel = "Grant DND Permission"
            )
        }
    }

    fun checkWriteSettings(): Capability {
        return if (Settings.System.canWrite(context)) {
            Capability(
                name = "Screen Brightness Control",
                status = Status.SUPPORTED,
                detail = "✅ Permission granted — can adjust brightness for battery savings."
            )
        } else {
            Capability(
                name = "Screen Brightness Control",
                status = Status.PERMISSION_NEEDED,
                detail = "⚠ Requires 'Modify System Settings' permission.",
                actionLabel = "Grant Write Settings"
            )
        }
    }

    fun checkGameManager(): Capability {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val gm = context.getSystemService(GameManager::class.java)
            if (gm != null) {
                Capability(
                    name = "Android GameManager API",
                    status = Status.UNAVAILABLE,
                    detail = "⚠ GameManager present (API 33+) but setGameMode() requires " +
                             "system-level privileges. Read-only access available. " +
                             "Use Xiaomi HyperOS Game Turbo for full control."
                )
            } else {
                Capability(
                    name = "Android GameManager API",
                    status = Status.UNAVAILABLE,
                    detail = "❌ GameManager not available on this device."
                )
            }
        } else {
            Capability(
                name = "Android GameManager API",
                status = Status.UNAVAILABLE,
                detail = "❌ Requires Android 13+. Device runs Android ${Build.VERSION.RELEASE}."
            )
        }
    }

    fun checkThermalApi(): Capability {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Capability(
                name = "Thermal Status Monitoring",
                status = Status.SUPPORTED,
                detail = "✅ PowerManager.getThermalStatus() available (API 29+). " +
                         "Reports throttling level in real-time."
            )
        } else {
            Capability(
                name = "Thermal Status Monitoring",
                status = Status.UNAVAILABLE,
                detail = "❌ Requires API 29+."
            )
        }
    }

    fun checkUsageStats(): Capability {
        val mode = context.packageManager.checkPermission(
            "android.permission.PACKAGE_USAGE_STATS",
            context.packageName
        )
        return Capability(
            name = "App Usage Statistics",
            status = if (mode == 0) Status.SUPPORTED else Status.PERMISSION_NEEDED,
            detail = if (mode == 0)
                "✅ UsageStatsManager accessible — can identify recently used apps."
            else
                "⚠ 'Usage Access' permission needed. Grant in Settings → Apps → Special access.",
            actionLabel = if (mode == 0) null else "Grant Usage Access"
        )
    }

    fun checkCpuFreqRead(): Capability {
        val path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"
        val readable = try { File(path).readText(); true } catch (_: Exception) { false }
        return Capability(
            name = "CPU Frequency Monitoring",
            status = if (readable) Status.SUPPORTED else Status.UNAVAILABLE,
            detail = if (readable)
                "✅ sysfs CPU frequency readable — showing real-time MHz."
            else
                "⚠ /sys/.../scaling_cur_freq not readable (common on HyperOS). " +
                "CPU load from /proc/stat still works."
        )
    }

    fun checkGpuFreqRead(): Capability {
        val paths = listOf(
            "/sys/kernel/gpu/gpu_freq",
            "/sys/devices/platform/mali.0/devfreq/mali.0/cur_freq"
        )
        val readable = paths.any { try { File(it).readText(); true } catch (_: Exception) { false } }
        return Capability(
            name = "GPU Frequency Monitoring",
            status = if (readable) Status.SUPPORTED else Status.UNAVAILABLE,
            detail = if (readable)
                "✅ GPU frequency readable from sysfs."
            else
                "❌ GPU sysfs not readable without root on this device. " +
                "GPU info not available."
        )
    }

    fun checkCpuOverclock() = Capability(
        name = "CPU Overclocking",
        status = Status.UNAVAILABLE,
        detail = "❌ NOT POSSIBLE without root + unlocked bootloader. " +
                 "Changing CPU governor or frequency limits requires kernel write access. " +
                 "HyperOS 2 on locked Redmi 13C 5G blocks all such interfaces."
    )

    fun checkGpuOverclock() = Capability(
        name = "GPU Overclocking",
        status = Status.UNAVAILABLE,
        detail = "❌ NOT POSSIBLE without root + unlocked bootloader. " +
                 "MediaTek GPU devfreq control requires privileged system access. " +
                 "No public API exists for this on non-rooted devices."
    )
}
