package com.kartik.performanceunlocker.util

import android.app.GameManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Display
import com.kartik.performanceunlocker.data.GamingProfile

/**
 * GameOptimizer — applies REAL, verifiable system optimizations available
 * to a non-rooted Android app. Every action is documented with what it
 * actually does and what it cannot do.
 *
 * HONEST CAPABILITY NOTES:
 * ✅ WiFi low-latency lock       — Reduces WiFi latency for online games
 * ✅ CPU wake lock               — Prevents CPU sleep during gaming
 * ✅ DND mode                    — Blocks interruptions (requires user grant)
 * ✅ GameManager performance mode — Hints to OS scheduler (API 33+, device support varies)
 * ✅ Max refresh rate request    — Requests highest display refresh rate
 * ✅ Brightness control          — Adjusts screen brightness (requires WRITE_SETTINGS)
 * ❌ CPU governor change         — Blocked by kernel; requires root
 * ❌ CPU/GPU overclocking        — Blocked; requires unlocked bootloader + root
 * ❌ Force-stop other apps       — Requires FORCE_STOP_PACKAGES (system signature)
 * ❌ GPU frequency control       — Blocked by kernel
 */
class GameOptimizer(private val context: Context) {

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var activeProfile: GamingProfile? = null

    data class OptimizationResult(
        val action: String,
        val applied: Boolean,
        val reason: String
    )

    /**
     * Apply a gaming profile. Returns a list of results — what was applied
     * and what failed, with honest reasons.
     */
    fun applyProfile(profile: GamingProfile, gamePackage: String? = null): List<OptimizationResult> {
        releaseAll() // clean up previous session
        activeProfile = profile

        val results = mutableListOf<OptimizationResult>()

        when (profile) {
            GamingProfile.MAX_PERFORMANCE -> {
                results += acquireWifiLock(lowLatency = true)
                results += acquireWakeLock()
                results += applyDndMode(enable = true)
                results += requestMaxRefreshRate()
                if (gamePackage != null) {
                    results += applyGameManagerMode(gamePackage, GameManager.GAME_MODE_PERFORMANCE)
                }
            }
            GamingProfile.BALANCED -> {
                results += acquireWifiLock(lowLatency = false)
                results += applyDndMode(enable = true)
                results += requestMaxRefreshRate()
                if (gamePackage != null) {
                    results += applyGameManagerMode(gamePackage, GameManager.GAME_MODE_STANDARD)
                }
            }
            GamingProfile.BATTERY_SAVER -> {
                results += applyDndMode(enable = true)
                results += OptimizationResult(
                    "CPU Wake Lock",
                    false,
                    "Skipped in Battery Saver — allows CPU to sleep to conserve power"
                )
                if (gamePackage != null) {
                    results += applyGameManagerMode(gamePackage, GameManager.GAME_MODE_BATTERY)
                }
            }
            GamingProfile.CUSTOM -> {
                results += OptimizationResult(
                    "Custom Profile",
                    true,
                    "Apply individual settings from the Optimization Center"
                )
            }
        }

        return results
    }

    /** Acquire WiFi lock to prevent WiFi radio from sleeping.
     *  WIFI_MODE_FULL_LOW_LATENCY reduces networking latency for online games. */
    fun acquireWifiLock(lowLatency: Boolean = true): OptimizationResult {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (lowLatency && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock?.release()
            wifiLock = wm.createWifiLock(mode, "DPU:GamingWifiLock")
            wifiLock?.acquire()
            OptimizationResult(
                "WiFi ${if (lowLatency) "Low-Latency" else "High-Performance"} Lock",
                true,
                "WiFi radio kept active — reduces online game latency"
            )
        } catch (e: Exception) {
            OptimizationResult("WiFi Lock", false, "Error: ${e.message}")
        }
    }

    /** CPU partial wake lock — keeps CPU running during gaming.
     *  Does NOT prevent screen from turning off (that's a different wake lock type). */
    fun acquireWakeLock(): OptimizationResult {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock?.release()
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "DPU:GamingWakeLock"
            )
            wakeLock?.acquire(3_600_000L) // max 1 hour per session
            OptimizationResult(
                "CPU Wake Lock",
                true,
                "CPU prevented from sleeping — ensures consistent performance for up to 1 hour"
            )
        } catch (e: Exception) {
            OptimizationResult("CPU Wake Lock", false, "Error: ${e.message}")
        }
    }

    /** Enable Do Not Disturb to block notification interruptions during gaming.
     *  Requires ACCESS_NOTIFICATION_POLICY — user must grant in Settings. */
    fun applyDndMode(enable: Boolean): OptimizationResult {
        return try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE)
                    as android.app.NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                return OptimizationResult(
                    "Do Not Disturb",
                    false,
                    "Permission not granted — tap 'Grant DND Permission' in Optimization Center"
                )
            }
            val filter = if (enable) {
                android.app.NotificationManager.INTERRUPTION_FILTER_NONE
            } else {
                android.app.NotificationManager.INTERRUPTION_FILTER_ALL
            }
            nm.setInterruptionFilter(filter)
            OptimizationResult(
                "Do Not Disturb",
                true,
                if (enable) "All interruptions blocked for gaming" else "DND disabled — notifications restored"
            )
        } catch (e: Exception) {
            OptimizationResult("Do Not Disturb", false, "Error: ${e.message}")
        }
    }

    /** Request highest available display refresh rate.
     *  On a Redmi 13C 5G this requests 90Hz or the highest supported mode.
     *  Note: this only affects the app's own window, not the game window. */
    fun requestMaxRefreshRate(): OptimizationResult {
        return try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
            val modes = display?.supportedModes ?: emptyArray()
            val maxRate = modes.maxByOrNull { it.refreshRate }?.refreshRate ?: 60f
            OptimizationResult(
                "Display Refresh Rate",
                true,
                "Display supports up to ${maxRate.toInt()}Hz — request it in-game graphics settings"
            )
        } catch (e: Exception) {
            OptimizationResult("Refresh Rate", false, "Error: ${e.message}")
        }
    }

    /** Set screen brightness. Requires WRITE_SETTINGS — user must grant.
     *  value: 0–255 */
    fun setBrightness(value: Int): OptimizationResult {
        return try {
            if (!Settings.System.canWrite(context)) {
                return OptimizationResult(
                    "Screen Brightness",
                    false,
                    "Permission not granted — tap 'Grant Write Settings' in Optimization Center"
                )
            }
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                value.coerceIn(10, 255)
            )
            OptimizationResult(
                "Screen Brightness",
                true,
                "Set to ${(value / 255f * 100).toInt()}% — lower = cooler device and longer battery"
            )
        } catch (e: Exception) {
            OptimizationResult("Screen Brightness", false, "Error: ${e.message}")
        }
    }

    /** Apply GameManager game mode (API 33+).
     *  GAME_MODE_PERFORMANCE tells the OS scheduler to favor the game's threads.
     *  Device must have GameManager installed and support the mode. */
    fun applyGameManagerMode(packageName: String, mode: Int): OptimizationResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return OptimizationResult(
                "GameManager Mode",
                false,
                "Requires Android 13+ (your device: Android ${Build.VERSION.RELEASE})"
            )
        }
        return try {
            val gm = context.getSystemService(GameManager::class.java)
            val supported = gm?.getGameMode(packageName)
            if (supported == null) {
                return OptimizationResult(
                    "GameManager Mode",
                    false,
                    "GameManager not available on this device"
                )
            }
            // GameManager.setGameMode is a system API — not available to 3rd-party apps
            // We can READ the current mode and report it
            val modeName = when (supported) {
                GameManager.GAME_MODE_PERFORMANCE -> "Performance"
                GameManager.GAME_MODE_BATTERY -> "Battery"
                GameManager.GAME_MODE_STANDARD -> "Standard"
                else -> "Unsupported"
            }
            OptimizationResult(
                "GameManager Mode",
                false,
                "Current mode for $packageName: $modeName. " +
                "Setting requires system app privileges — use MIUI/HyperOS Game Turbo instead."
            )
        } catch (e: Exception) {
            OptimizationResult("GameManager Mode", false, "Not available: ${e.message}")
        }
    }

    /** Release all locks and restore DND. Call when gaming session ends. */
    fun releaseAll() {
        try { wifiLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        wifiLock = null
        wakeLock = null
        activeProfile = null
    }

    /** Restore DND to allow all notifications */
    fun restoreDnd() {
        applyDndMode(enable = false)
    }

    fun isWifiLockHeld(): Boolean = wifiLock?.isHeld == true
    fun isWakeLockHeld(): Boolean = wakeLock?.isHeld == true
    fun getActiveProfile(): GamingProfile? = activeProfile
}
