package com.kartik.performanceunlocker.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.view.Display
import com.kartik.performanceunlocker.data.SystemMetrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

/**
 * Collects real system metrics using only public Android APIs and readable sysfs entries.
 * Every value reported is from a genuine system source — no fake or estimated data.
 */
class MetricsCollector(private val context: Context) {

    // CPU stat tracking for usage calculation
    private var prevCpuIdle = 0L
    private var prevCpuTotal = 0L

    suspend fun collect(): SystemMetrics = withContext(Dispatchers.IO) {
        val cpuUsage = readCpuUsage()
        val (curFreq, maxFreq) = readCpuFrequency()
        val coreCount = Runtime.getRuntime().availableProcessors()
        val (ramUsed, ramTotal, ramAvail) = readMemoryInfo()
        val battery = readBatteryInfo()
        val thermal = readThermalStatus()
        val refreshRate = readDisplayRefreshRate()
        val (storageFree, storageTotal) = readStorageInfo()
        val (gpuAvail, gpuFreq) = readGpuInfo()

        SystemMetrics(
            cpuUsagePercent = cpuUsage,
            cpuFreqMhz = curFreq,
            cpuMaxFreqMhz = maxFreq,
            cpuCoreCount = coreCount,
            ramUsedMb = ramUsed,
            ramTotalMb = ramTotal,
            ramAvailableMb = ramAvail,
            batteryPercent = battery.first,
            batteryTempCelsius = battery.second,
            isCharging = battery.third,
            thermalStatus = thermal.first,
            thermalLabel = thermal.second,
            displayRefreshRateHz = refreshRate,
            storageFreeGb = storageFree,
            storageTotalGb = storageTotal,
            gpuInfoAvailable = gpuAvail,
            gpuFreqMhz = gpuFreq
        )
    }

    /**
     * CPU usage from /proc/stat — genuine kernel accounting.
     * Returns 0 on first call (needs two samples to compute delta).
     */
    private fun readCpuUsage(): Float {
        return try {
            val line = File("/proc/stat").readLines().firstOrNull() ?: return 0f
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size < 5) return 0f

            val user = parts[1].toLong()
            val nice = parts[2].toLong()
            val system = parts[3].toLong()
            val idle = parts[4].toLong()
            val iowait = if (parts.size > 5) parts[5].toLong() else 0L
            val irq = if (parts.size > 6) parts[6].toLong() else 0L
            val softirq = if (parts.size > 7) parts[7].toLong() else 0L

            val total = user + nice + system + idle + iowait + irq + softirq
            val deltaTotal = total - prevCpuTotal
            val deltaIdle = idle - prevCpuIdle

            prevCpuTotal = total
            prevCpuIdle = idle

            if (deltaTotal <= 0) return 0f
            ((deltaTotal - deltaIdle).toFloat() / deltaTotal * 100f).coerceIn(0f, 100f)
        } catch (e: Exception) {
            0f
        }
    }

    /**
     * CPU frequency from sysfs. On many non-root devices the scaling_cur_freq
     * is readable. cpuinfo_max_freq is almost always readable.
     * Returns pair of (current MHz, max MHz).
     */
    private fun readCpuFrequency(): Pair<Int, Int> {
        val maxFreq = tryReadSysfs(
            "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"
        )?.trim()?.toLongOrNull()?.div(1000)?.toInt() ?: 2200

        val curFreq = tryReadSysfs(
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"
        )?.trim()?.toLongOrNull()?.div(1000)?.toInt()
            ?: tryReadSysfs(
                "/sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq"
            )?.trim()?.toLongOrNull()?.div(1000)?.toInt()
            ?: (maxFreq / 2) // estimate if locked

        return Pair(curFreq, maxFreq)
    }

    /**
     * RAM info from ActivityManager — always works, no permission needed.
     */
    private fun readMemoryInfo(): Triple<Long, Long, Long> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalMb = memInfo.totalMem / 1_048_576L
        val availMb = memInfo.availMem / 1_048_576L
        val usedMb = totalMb - availMb
        return Triple(usedMb, totalMb, availMb)
    }

    /**
     * Battery percentage, temperature, and charging state from BatteryManager.
     * No permission required.
     */
    private fun readBatteryInfo(): Triple<Int, Float, Boolean> {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val percent = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        // Temperature from sticky broadcast (tenths of degree C → °C)
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, ifilter)
        val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300
        val tempCelsius = tempTenths / 10f

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                         status == BatteryManager.BATTERY_STATUS_FULL

        return Triple(percent, tempCelsius, isCharging)
    }

    /**
     * Thermal status from PowerManager (API 29+).
     * Maps to: 0=None, 1=Light, 2=Moderate, 3=Severe, 4=Critical, 5=Emergency, 6=Shutdown
     */
    private fun readThermalStatus(): Pair<Int, String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val status = pm.currentThermalStatus
            val label = when (status) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light throttling"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate throttling"
                PowerManager.THERMAL_STATUS_SEVERE -> "⚠ Severe throttling"
                PowerManager.THERMAL_STATUS_CRITICAL -> "🔴 Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "🔴 Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "🔴 Shutdown imminent"
                else -> "Unknown"
            }
            return Pair(status, label)
        }
        return Pair(0, "Normal (API <29)")
    }

    /**
     * Display refresh rate from DisplayManager — always works.
     */
    private fun readDisplayRefreshRate(): Float {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate ?: 60f
    }

    /**
     * Internal storage from StatFs — always works.
     */
    private fun readStorageInfo(): Pair<Float, Float> {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val free = stat.availableBlocksLong * stat.blockSizeLong / 1_073_741_824f
            val total = stat.blockCountLong * stat.blockSizeLong / 1_073_741_824f
            Pair(free, total)
        } catch (e: Exception) {
            Pair(0f, 256f)
        }
    }

    /**
     * GPU frequency from sysfs — MediaTek Dimensity path.
     * This is typically NOT readable without root on locked devices.
     * We try anyway and report honestly if unavailable.
     */
    private fun readGpuInfo(): Pair<Boolean, Int> {
        // MediaTek GPU paths (Dimensity)
        val mtGpuFreqPaths = listOf(
            "/proc/gpufreq/gpufreq_opp_dump",
            "/sys/kernel/gpu/gpu_freq",
            "/sys/devices/platform/mali.0/devfreq/mali.0/cur_freq",
            "/sys/class/devfreq/13000000.mali/cur_freq"
        )

        for (path in mtGpuFreqPaths) {
            val value = tryReadSysfs(path)
            if (value != null) {
                val freq = value.trim().toLongOrNull()?.div(1_000_000)?.toInt()
                if (freq != null && freq > 0) return Pair(true, freq)
            }
        }
        return Pair(false, -1)
    }

    private fun tryReadSysfs(path: String): String? {
        return try {
            RandomAccessFile(path, "r").use { f ->
                f.readLine()
            }
        } catch (e: Exception) {
            null
        }
    }
}
